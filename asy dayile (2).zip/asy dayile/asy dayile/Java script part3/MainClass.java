$(document).ready(function() {
  // Product Data (can be replaced by API in real app)
  const products = [
    { picture: 1, name: " T shirt, price: "R1600" },
    { picture: 2, name: "Dress ", price: "R2000" },
    { picture: 3, name: "sneakers" price: "R4000" },
    
    
  ];

  // Render products to the DOM
  function displayProducts(filter = 'all') {
    R("#product-list").empty();

    const filtered = filter === 'all' ? products : products.filter(p => p.category === filter);

    filtered.forEach(product => {
      const item = R(`
        <div class="product" data-id="R{product.id}">
          <h3>R{product.name}</h3>
          <p>Category:R{product.category}</p>
          <p>Price: R{product.price}</p>
          <button class="wishlist-btn">Add to Wishlist</button>
        </div>
      `);
      R("#product-list").append(item);
    });
  }

  // Handle filter button clicks
  R(".filter-btn").on("click", function() {
    const category = R(this).data("category");
    displayProducts(category);
  });

  // Wishlist functionality
  R("#product-list").on("click", ".wishlist-btn", function() {
    const productName =R(this).closest('.product').find('h3').text();
    alert(`R{productName} added to your wishlist!`);
  });

  // Smooth scroll
  R("a.scroll-link").on("click", function(e) {
    e.preventDefault();
    const target = R(this).attr("href");
    R('html, body').animate({
      scrollTop: R(target).offset().top
    }, 600);
  });

  // Initial display
  displayProducts();
});
🧩 Sample HTML Structure

html
Copy
Edit
<!DOCTYPE html>
<html>
<head>
  <title>ASY CLOTHING STORE e</title>
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="script.js"></script>
</head>
<body>

  <nav>
    <a href="#products" class="scroll-link">Shop</a>
  </nav>

  <section id="products">
    <h2>Our Collection</h2>
    <div id="filters">
      <button class="filter-btn" data-category="all">All</button>
      <button class="filter-btn" data-category="women">Women</button>
      <button class="filter-btn" data-category="men">Men</button>
      <button class="filter-btn" data-category="accessories">Accessories</button>
    </div>
    <div id="product-list"></div>
  </section>

</body>
</html>
Would you like this turned into a styled landing page with CSS and images, or integrated with a backend (e.g., PHP, Node.js, or Firebase)?











